# CycleSum Lite v1.0.5.1 (GA)

**CycleSum Lite** is a fully local AI PDF summarizer.  
All processing runs offline on your machine. Nothing is sent to the cloud.

No account, telemetry, or internet is required after setup.

---

## Pipeline


> *(OCR for scanned PDFs is scheduled for v1.1)*

---

##System Requirements

| Tier                      | CPU / RAM                       | Storage         | GPU (optional)                     |
| ------------------------- | ------------------------------- | ----------------| ---------------------------------- |
| **CPU-only (Φ-3 Mini)**   | 4-core AVX2 · 8 GB              | ≥300 MB         | —                                  |
| **Recommended CPU**       | 6-core · 16 GB                  | ≥1 GB           | —                                  |
| **GPU mode (LLaMA 3)**    | Quad-core · 32 GB               | ≥5 GB           | ≥ RTX 3060 12 GB / RX 6800 16 GB   |          
| **OS**                    | Windows 10 64-bit, macOS 12+, Ubuntu 20.04+ | 

> On first run, CycleSum Lite will prompt to download **Φ-3 Mini (~268 MB)**.  
> GPU users may install LLaMA 3 8B (~4 GB) manually via:  
> `bash scripts/install_llama3.sh`

---

## Quick Start

```bash
# unzip anywhere
unzip CycleSum_Lite_v1.0.5.1-GA.zip -d cyclesum

# optional: download Φ-3 Mini
bash cyclesum/scripts/install_phi3.sh


# Legal Notice & Disclaimer
---
## Notice & Disclaimer
Current privacy & license disclaimer is avaliable and updated at cyclecore.ai/notice.
CycleSum Lite shows legal notice on first launch and requires acceptance before use.

```

