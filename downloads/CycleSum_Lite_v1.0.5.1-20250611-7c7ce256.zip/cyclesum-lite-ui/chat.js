/* CycleSum Lite — chat.js (Clean build • 2025-06-09)
   --------------------------------------------------
   • Works with original Tailwind CSS
   • Dark mode default; toggle flips entire palette
   • File-input hidden (no duplicate Browse)
   • Upload → summary → download flow
*/

(function () {
  const API_BASE = window.API_BASE || "http://localhost:8000";

  /* ---------- Helpers ---------- */
  function getPublicModelLabel(id) {
    return id === "llama3:8b" ? "GPU LLM (Fast)"
         : id === "phi3"      ? "CPU LLM"
         : "Basic Model";
  }

  const DISCLAIMER_FOOTER =
    "\n\n---\nDisclaimer: AI generated. Not professional advice. Always verify.";

  function setBadge(level, badge) {
    const dark = document.documentElement.classList.contains("dark");
    const color =
      level === "High"   ? (dark ? "bg-green-400 text-black" : "bg-green-600 text-white") :
      level === "Medium" ? (dark ? "bg-yellow-200 text-black" : "bg-yellow-300 text-black") :
      level === "Low"    ? (dark ? "bg-red-400 text-black"   : "bg-red-500 text-white") :
                           "";
    badge.textContent = `Confidence: ${level}`;
    badge.className   = `font-bold mb-2 px-2 py-1 rounded inline-block ${color}`;
  }

  /* ---------- DOM ready ---------- */
  window.addEventListener("DOMContentLoaded", () => {

    /* Theme restore (default dark) */
    if (localStorage.theme === "light") {
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
    }
    document.body.classList.toggle("dark",
      document.documentElement.classList.contains("dark"));

    /* Element refs */
    const modelSelect  = document.getElementById("modelSelect");
    const domainSelect = document.getElementById("domainSelect");
    const fileInput    = document.getElementById("fileInput");
    const uploadBtn    = document.getElementById("uploadBtn");
    const uploadBar    = document.getElementById("uploadBar");
    const downloadBtn  = document.getElementById("downloadBtn");
    const summaryBox   = document.getElementById("summary-text");
    const badge        = document.getElementById("confidence-badge");

    fileInput.style.display = "none";         // hide native Browse

    /* Persist domain */
    const savedDomain = localStorage.getItem("cyclesum_domain");
    if (savedDomain) domainSelect.value = savedDomain;
    domainSelect.addEventListener("change",
      () => localStorage.setItem("cyclesum_domain", domainSelect.value));

    /* Upload trigger */
    uploadBtn.addEventListener("click", () => fileInput.click());

    /* Upload handler */
    fileInput.addEventListener("change", () => {
      const file = fileInput.files[0];
      if (!file) return;

      summaryBox.textContent = "Loading summary…";
      badge.textContent      = "Loading confidence…";

      uploadBar.hidden = false;
      uploadBar.value  = 0;

      const xhr = new XMLHttpRequest();
      xhr.open("POST", `${API_BASE}/api/summarize-pdf`, true);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) uploadBar.value = (e.loaded / e.total) * 100;
      };

      xhr.onload = () => {
        uploadBar.hidden = true;
        uploadBar.value  = 0;

        try {
          const { summary, confidence } = JSON.parse(xhr.responseText);

          const now   = new Date();
          const dStr  = now.toISOString().split("T")[0];
          const tStr  = now.toTimeString().split(" ")[0].slice(0,5);
          const memoHeader =
`CycleSum Lite Memo
Date: ${dStr} · Time: ${tStr}
Model: ${getPublicModelLabel(modelSelect.value)}
Confidence: ${confidence}
Summary Type: ${domainSelect.value.charAt(0).toUpperCase() + domainSelect.value.slice(1)}

Summary:\n\n`;

          summaryBox.textContent = memoHeader + summary + DISCLAIMER_FOOTER;
          setBadge(confidence, badge);

        } catch (err) {
          summaryBox.textContent = "⚠️ Failed to load summary.";
          badge.textContent      = "⚠️";
          console.error("Parse error:", err);
        }
      };

      const fd = new FormData();
      fd.append("file",   file);
      fd.append("model",  modelSelect.value);
      fd.append("domain", domainSelect.value);
      xhr.send(fd);
    });

    /* Download memo */
    downloadBtn.addEventListener("click", () => {
      const memoText = summaryBox.innerText || "";
      if (!memoText.trim()) return;

      const now  = new Date();
      const name =
        `cyclesum_memo_${now.toISOString().slice(0,10)}_${now.toTimeString().slice(0,8).replace(/:/g,"")}.txt`;

      const blob = new Blob([memoText], { type: "text/plain" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = name;
      link.click();
    });
  });

  /* ---------- Dark/light toggle ---------- */
  window.lmToggleTheme = () => {
    const html  = document.documentElement;
    const dark  = html.classList.toggle("dark");
    document.body.classList.toggle("dark", dark);
    localStorage.theme = dark ? "dark" : "light";

    const badge = document.getElementById("confidence-badge");
    if (badge && badge.textContent.startsWith("Confidence: ")) {
      setBadge(badge.textContent.replace("Confidence: ", ""), badge);
    }
  };

})();
