#!/usr/bin/env bash
set -e
MODEL_DIR="models/phi3-mini"
MODEL_URL="https://ollama.com/library/phi3%3Amini"   # primary :contentReference[oaicite:0]{index=0}
BACKUP_URL="https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf"   # backup :contentReference[oaicite:1]{index=1}
MODEL_BIN="$MODEL_DIR/phi3-mini.bin"
SHA_REF="PUT_REAL_HASH_HERE"
mkdir -p "$MODEL_DIR"
if [[ -f "$MODEL_BIN" ]]; then echo "Φ-3 already present"; exit 0; fi
echo "Downloading Φ-3 Mini…"; curl -L -o "$MODEL_BIN.tmp" "$MODEL_URL"
echo "Verifying…"; sha=$(sha256sum "$MODEL_BIN.tmp" | awk '{print $1}')
[[ "$sha" == "$SHA_REF" ]] || { echo "Hash mismatch!"; exit 1; }
mv "$MODEL_BIN.tmp" "$MODEL_BIN"; echo "Φ-3 installed at $MODEL_BIN"
